--[[
	tullaRangeConfig localization
--]]

TULLARANGE_CONFIG_LOCALS = TULLARANGE_CONFIG_LOCALS or {}
local L = TULLARANGE_CONFIG_LOCALS
if not L then 
	return 
end

L.ColorSettings = 'Colors'
L.ColorSettingsTitle = 'tullaRange color configuration settings.'
L.Color_oor = 'Out of Range Color'
L.Color_oom = 'Out of Mana Color'