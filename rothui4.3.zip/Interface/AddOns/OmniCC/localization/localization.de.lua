--[[
	OmniCC localization - deDE
--]]

if GetLocale() ~= 'deDE' then return end

local L = OMNICC_LOCALS

L.Updated = "Aktualisiert auf v%s"
L.None = NONE
L.Pulse = "Pulse"
L.Shine = "Shine"