local _NAME, _NS = ...

_NS.L = {
	fish = "Fishy loot",
	empty = "Empty slot",

	uiTitleSize = 'Title font size:',
	uiItemSize = 'Item font size:',
	uiCountSize = 'Count font size:',
	uiIconSize = 'Item icon size:',
	uiFrameScale = 'Frame scale:',
}

