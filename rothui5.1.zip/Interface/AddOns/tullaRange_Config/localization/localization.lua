--[[
	tullaRangeConfig localization
--]]

TULLARANGE_CONFIG_LOCALS = TULLARANGE_CONFIG_LOCALS or {}
local L = TULLARANGE_CONFIG_LOCALS
if not L then 
	return 
end

L.ColorSettings = 'Colors'
L.ColorSettingsTitle = 'tullaRange color configuration settings.'
L.Color_oor = 'Out of Range'
L.Color_oom = 'Out of Mana'
L.Color_ooh = 'Below Maximum Holy Power'

L.HolyPowerThreshold = 'Holy Power Threshold'