-- Kill the default loot frame.
LootFrame:UnregisterAllEvents()

-- Escape the dungeon.
table.insert(UISpecialFrames, "Butsu")
