local _NAME, _NS = ...

_NS.L = {
	fish = "Fishy loot",
	empty = "Empty slot",

	uiFontSizeTitle = 'Font size',
	uiTitleSize = 'Title',
	uiItemSize = 'Item',
	uiCountSize = 'Count',

	uiScaleSizeTitle = 'Scale and size',
	uiIconSize = 'Icon size',
	uiFrameScale = 'Frame scale',
}
